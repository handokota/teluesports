<style>
    .active {
        color: #00917A;
    }
    
    .btn-primary {
        background-color: #00917A;
        border: none;
        width: 120px;
        font-size: 16px;
        box-shadow: 0 5px 10px rgba(0,0,0,.2) !important;
    }

    .btn-primary:hover {
        transition: 0.5s;
        background-color: #006655;
    }
</style>
<nav class="navbar">
  <a href="<?php echo base_url('/Homepage_ctrl'); ?>"><img class="navbar-brand" src="assets/img/logo.png" alt="logo"></a>
  <ul class="nav-links">
    <div class="menu">
      <li><a href="<?php echo base_url('/Homepage_ctrl'); ?>" class="<?php if($this->session->userdata('active_nav')=='homepage'){echo'active';}?>">Home</a></li>
      <li><a href="<?php echo base_url('/Divisions_ctrl'); ?>" class="<?php if($this->session->userdata('active_nav')=='division'){echo'active';}?>">Divisions</a></li>
      <li><a href="<?php echo base_url('/Admin_member_ctrl'); ?>" class="<?php if($this->session->userdata('active_nav')=='member'){echo'active';}?>">Member</a></li>
      <li><a href="<?php echo base_url('/Partnership_ctrl'); ?>" class="<?php if($this->session->userdata('active_nav')=='partnership'){echo'active';}?>">Partnership</a></li>
      <?php 		
        if($this->session->has_userdata("username")) {
          echo '<li><a href="'; echo base_url('/Event_ctrl'); echo'" class="'; if($this->session->userdata('active_nav')=='event'){echo'active';}echo'">Events</a></li>';
        }
      ?>
      <li><a href="<?php echo base_url('/Aboutus_ctrl'); ?>" class="<?php if($this->session->userdata('active_nav')=='aboutus'){echo'active';}?>">About us</a></li>
      <div class="contact text-center">
        <button href="#" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#exampleModal" style="background-color: transparent;">Contact us</button>
            <!-- Modal -->
            <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
              <div class="modal-dialog">
                <div class="modal-content bg-dark rounded">
                  <div class="modal-header" style="border: none;">
                    <h5 class="modal-title">Contact us</h5>
                    <button type="button" class="btn btn-close btn-outline-success" data-bs-dismiss="modal" aria-label="Close"></button>
                  </div>
                  <div class="modal-body">
                    <div class="container">
                      <div class="table-responsive">
                        <table class="table table-dark">
                            <tbody>
                                <tr>
                                  <td class="text-center" style="border: none;">
                                    <a href="mailto:teluesports@gmail.com" target="_blank">
                                      <img src="assets/img/email.png">
                                    </a>
                                  </td>
                                  <td class="text-center" style="border: none;">
                                    <a href="https://www.instagram.com/teluesports/" target="_blank">
                                      <img src="assets/img/instagram.png">
                                    </a>
                                  </td>
                                  <td class="text-center" style="border: none;">
                                    <a href="https://www.youtube.com/@TELUESPORTS" target="_blank">
                                      <img src="assets/img/youtube.png">
                                    </a>
                                  </td>
                                </tr>
                                <tr>
                                    <td class="text-center" style="border: none;">Email</td>
                                    <td class="text-center" style="border: none;">Instagram</td>
                                    <td class="text-center" style="border: none;">YouTube</td>
                                </tr>
                                <tr>
                                  <td style="border: none;"></td>
                                </tr>
                                <tr>
                                  <td class="text-center" style="border: none;">
                                    <a href="https://page.line.me/?accountId=qiw5424h" target="_blank">
                                      <img src="assets/img/line.png">
                                    </a>
                                  </td>
                                  <td class="text-center" style="border: none;">
                                    <a href="https://www.linkedin.com/company/telkom-university-esports" target="_blank">
                                      <img src="assets/img/linkind.png">
                                    </a>
                                  </td>
                                  <td class="text-center" style="border: none;">
                                    <a href="https://www.tiktok.com/@teluesports" target="_blank">
                                      <img src="assets/img/tiktok.png">
                                    </a>
                                  </td>
                                </tr>
                                <tr>
                                    <td class="text-center" style="border: none;">OA Line</td>
                                    <td class="text-center" style="border: none;">LinkedIn</td>
                                    <td class="text-center" style="border: none;">Facebook</td>
                                </tr>
                            </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
      </div>
      <div class="login">
        <?php 
        if(!$this->session->has_userdata("username")){
          echo '
          <button href="#" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#loginModal" style="background-color: #00917A;">Login</button>
          <!-- Modal -->
          <div class="modal fade" id="loginModal" tabindex="-1" aria-labelledby="loginModalLabel" aria-hidden="true">
            <div class="modal-dialog">
              <div class="modal-content bg-dark rounded">
                <div class="modal-header" style="border: none;">
                  <h5 class="modal-title">Login</h5>
                  <button type="button" class="btn btn-close btn-outline-success" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                  <div class="container">
                    <div class="table-responsive">
                      <form method="POST" action=" ';echo base_url("/Homepage_ctrl/login"); echo'">
                        <div class="form-group">
                          <label for="exampleInputEmail1"">Username</label>
                          <input type="text" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" placeholder="" name="username"><br>
                        </div>
                        <div class="form-group">
                          <label for="exampleInputPassword1">Password</label>
                          <input type="password" class="form-control" id="exampleInputPassword1" placeholder="" name="password">
                          <br>
                        </div>
                        <div class="login text-center">
                          <button type="submit" class="btn btn-primary">Login</button>
                        </div>  
                      </form>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          ';
        } else {
          echo '
          <form action=" ';echo base_url("/Homepage_ctrl/signout"); echo'" method="post">
          <button type="submit" class="btn btn-success" style="background-color: #00917A;">Signout</button>
          </form>
          ';
        }
        ?>
        
      </div>
  </ul>
</nav>

    