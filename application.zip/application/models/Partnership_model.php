<?php 
	defined('BASEPATH') OR exit('No direct script access alowed');

	class Partnership_model extends CI_Model 
	{

	}
?>